package com.publicis.sapient.productcatalogue.service;

import com.publicis.sapient.productcatalogue.controller.ProductController;
import com.publicis.sapient.productcatalogue.model.Product;
import com.publicis.sapient.productcatalogue.repository.ProductRepository;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class ProductServiceTest {

    @SpyBean
    private ProductService productService;

    @MockBean
    private ProductRepository productRepository;

    @BeforeEach
    void setUp() {
    }

    @Test
    void addProducts() {
    }

    @Test
    void findProductsByBrand() {
        List<Product> productList = Arrays.asList(new Product(2547,"shirt","S1P1","Brand Factory", "PepeJeans",3120L, "blue", "XL"));
        when(productRepository.findProductByBrand(anyString(),anyString())).thenReturn(productList);

        assertThat(productService.findProductsByBrand("PepeJeans","shirt")).isEqualTo(productList);
        verify(productRepository,times(1)).findProductByBrand(anyString(),anyString());
    }

    @Test
    void findProductsByPrice() {
        List<Product> productList = Arrays.asList(new Product(2547,"shirt","S1P1","Brand Factory", "PepeJeans",3120L, "blue", "XL"));
        when(productRepository.findProductsByPrice(anyLong(),anyLong(),anyString())).thenReturn(productList);

        assertThat(productService.findProductsByPrice(2000l,5000l,"shirt")).isEqualTo(productList);
        verify(productRepository,times(1)).findProductsByPrice(anyLong(),anyLong(),anyString());
    }

    @Test
    void findProductsByColour() {
        List<Product> productList = Arrays.asList(new Product(2547,"shirt","S1P1","Brand Factory", "PepeJeans",3120L, "blue", "XL"));
        when(productRepository.findProductsByColour(anyString(),anyString())).thenReturn(productList);

        assertThat(productService.findProductsByColour("blue","shirt")).isEqualTo(productList);
        verify(productRepository,times(1)).findProductsByColour(anyString(),anyString());
    }

    @Test
    void findProductsBySize() {
        List<Product> productList = Arrays.asList(new Product(2547,"shirt","S1P1","Brand Factory", "PepeJeans",3120L, "blue", "XL"));
        when(productRepository.findProductsBySize(anyString(),anyString())).thenReturn(productList);

        assertThat(productService.findProductsBySize("XL","shirt")).isEqualTo(productList);
        verify(productRepository,times(1)).findProductsBySize(anyString(),anyString());
    }

    @Test
    void findProductsBySku() {
        List<Product> productList = Arrays.asList(new Product(2547,"shirt","S1P1","Brand Factory", "PepeJeans",3120L, "blue", "XL"));
        when(productRepository.findProductsBySku(anyString())).thenReturn(productList);

        assertThat(productService.findProductsBySku("S1P1")).isEqualTo(productList);
        verify(productRepository,times(1)).findProductsBySku(anyString());
    }

    @Test
    void findProductsBySeller() {
        when(productRepository.findProductsBySeller(anyString(),anyString())).thenReturn(1);

        assertThat(productService.findProductsBySeller("Brand Factory","shirt")).isEqualTo(1);
        verify(productRepository,times(1)).findProductsBySeller(anyString(),anyString());
    }
}