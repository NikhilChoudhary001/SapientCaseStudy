package com.publicis.sapient.productcatalogue.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.publicis.sapient.productcatalogue.model.Product;
import com.publicis.sapient.productcatalogue.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest(ProductController.class)
class ProductControllerTest {

    static List<Product> productList = Arrays.asList(new Product(2547,"shirt","S1P1","Brand Factory", "PepeJeans",3120L, "blue", "XL"));

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    @BeforeEach
    void setUp() throws JsonProcessingException {
    }

    @Test
    void addProducts() throws Exception{
        String jsonList = "[{\"productId\" : 2547,\n" +
                "  \"category\" : \"shirt\",\n" +
                "  \"sku\" : \"S1P1\",\n" +
                "  \"brand\" : \"PepeJeans\",\n" +
                "  \"price\" : 3120 ,\n" +
                "  \"colour\" : \"blue\",\n" +
                "  \"size\" : \"XL\",\n" +
                "  \"seller\" : \"Brand Factory\"}]";
        Mockito.doNothing().when(productService).addProducts(Mockito.anyList());

        mockMvc.perform(MockMvcRequestBuilders.post("/v1/catalogue/addProducts")
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .content(jsonList))
                .andExpect(status().isOk());

        Mockito.verify(productService,Mockito.times(1)).addProducts(Mockito.anyList());

    }

    @Test
    void findProductsByBrand() throws Exception {

        when(productService.findProductsByBrand(anyString(),anyString())).thenReturn(productList);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/catalogue/findProductByBrand/{brand}/{category}","PepeJeans","shirt"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$[0].productId").value(2547))
                .andExpect(jsonPath("$[0].category").value("shirt"))
                .andExpect(jsonPath("$[0].sku").value("S1P1"))
                .andExpect(jsonPath("$[0].brand").value("PepeJeans"))
                .andExpect(jsonPath("$[0].price").value(3120))
                .andExpect(jsonPath("$[0].colour").value("blue"))
                .andExpect(jsonPath("$[0].size").value("XL"))
                .andExpect(jsonPath("$[0].seller").value("Brand Factory"));

        verify(productService,times(1)).findProductsByBrand(anyString(),anyString());
    }

    @Test
    void findProductsByPrice() throws Exception {
        when(productService.findProductsByPrice(anyLong(),anyLong(),anyString())).thenReturn(productList);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/catalogue/findProductByPrice/{minPrice}/{maxPrice}/{category}",2000,5000,"shirt"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$[0].productId").value(2547))
                .andExpect(jsonPath("$[0].category").value("shirt"))
                .andExpect(jsonPath("$[0].sku").value("S1P1"))
                .andExpect(jsonPath("$[0].brand").value("PepeJeans"))
                .andExpect(jsonPath("$[0].price").value(3120))
                .andExpect(jsonPath("$[0].colour").value("blue"))
                .andExpect(jsonPath("$[0].size").value("XL"))
                .andExpect(jsonPath("$[0].seller").value("Brand Factory"));

        verify(productService,times(1)).findProductsByPrice(anyLong(),anyLong(),anyString());
    }

    @Test
    void findProductsByColour() throws Exception {

        when(productService.findProductsByColour(anyString(),anyString())).thenReturn(productList);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/catalogue/findProductByColour")
                .param("colour","blue")
                .param("category","shirt"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$[0].productId").value(2547))
                .andExpect(jsonPath("$[0].category").value("shirt"))
                .andExpect(jsonPath("$[0].sku").value("S1P1"))
                .andExpect(jsonPath("$[0].brand").value("PepeJeans"))
                .andExpect(jsonPath("$[0].price").value(3120))
                .andExpect(jsonPath("$[0].colour").value("blue"))
                .andExpect(jsonPath("$[0].size").value("XL"))
                .andExpect(jsonPath("$[0].seller").value("Brand Factory"));

        verify(productService,times(1)).findProductsByColour(anyString(),anyString());
    }

    @Test
    void findProductsBySize() throws Exception {
        when(productService.findProductsBySize(anyString(),anyString())).thenReturn(productList);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/catalogue/findProductBySize/")
                .param("size","XL")
                .param("category","shirt"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$[0].productId").value(2547))
                .andExpect(jsonPath("$[0].category").value("shirt"))
                .andExpect(jsonPath("$[0].sku").value("S1P1"))
                .andExpect(jsonPath("$[0].brand").value("PepeJeans"))
                .andExpect(jsonPath("$[0].price").value(3120))
                .andExpect(jsonPath("$[0].colour").value("blue"))
                .andExpect(jsonPath("$[0].size").value("XL"))
                .andExpect(jsonPath("$[0].seller").value("Brand Factory"));

        verify(productService,times(1)).findProductsBySize(anyString(),anyString());
    }

    @Test
    void findProductsBySku() throws Exception {
        when(productService.findProductsBySku(anyString())).thenReturn(productList);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/catalogue/findProductBySku/")
                .param("sku","S1F1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$[0].productId").value(2547))
                .andExpect(jsonPath("$[0].category").value("shirt"))
                .andExpect(jsonPath("$[0].sku").value("S1P1"))
                .andExpect(jsonPath("$[0].brand").value("PepeJeans"))
                .andExpect(jsonPath("$[0].price").value(3120))
                .andExpect(jsonPath("$[0].colour").value("blue"))
                .andExpect(jsonPath("$[0].size").value("XL"))
                .andExpect(jsonPath("$[0].seller").value("Brand Factory"));

        verify(productService,times(1)).findProductsBySku(anyString());
    }

    @Test
    void findProductsBySeller() throws Exception {
        when(productService.findProductsBySeller(anyString(),anyString())).thenReturn(1);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/catalogue/findTotalProductsBySeller/")
                .param("seller","Brand Factory")
                .param("category","shirt"))
                .andExpect(status().isOk());

        verify(productService,times(1)).findProductsBySeller(anyString(),anyString());
    }
}