INSERT INTO PRODUCT (productId, category, sku, seller, brand, price, colour, size) VALUES
  (1456,'shirt','S1P1','BrandFactory', 'Pepe Jeans',3210, 'blue', 'L'),
  (5895,'shirt','S1P1','BrandFactory', 'UCB',4500, 'red', 'M'),
  (2586,'shirt','S1P1','BrandFactory', 'Levis',8952, 'black', 'XL');