package com.publicis.sapient.productcatalogue.controller;

import com.publicis.sapient.productcatalogue.model.Product;
import com.publicis.sapient.productcatalogue.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping(path = "/v1/catalogue")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping(value = "/addProducts", consumes = MediaType.APPLICATION_JSON_VALUE)
    public void addProducts(@RequestBody List<Product> products) throws Exception {

        productService.addProducts(products);
    }

    @GetMapping(value = "/getAllProducts", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> getAllProducts() throws Exception {

        return productService.getAllProducts();
    }

    @DeleteMapping("/deleteProduct/{productId}")
    public void deleteProduct(@PathVariable int productId) throws Exception {

        productService.deleteProduct(productId);
    }

    @GetMapping(value = "/findProductByBrand/{brand}/{category}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> findProductsByBrand(@PathVariable String brand, @PathVariable String category) throws Exception {

        return productService.findProductsByBrand(brand.toUpperCase(), category.toUpperCase());
    }

    @GetMapping(value = "/findProductByPrice/{minPrice}/{maxPrice}/{category}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> findProductsByPrice(@PathVariable Long minPrice, @PathVariable Long maxPrice, @PathVariable String category) throws Exception {

        return productService.findProductsByPrice(minPrice, maxPrice, category.toUpperCase());
    }

    @GetMapping(value = "/findProductByColour", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> findProductsByColour(@RequestParam String colour, @RequestParam String category) throws Exception {
        return productService.findProductsByColour(colour, category.toUpperCase());
    }

    @GetMapping(value = "/findProductBySize/", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> findProductsBySize(@RequestParam String size, @RequestParam String category) throws Exception {

        return productService.findProductsBySize(size, category.toUpperCase());
    }

    @GetMapping(value = "/findProductBySku", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> findProductsBySku(@RequestParam String sku) throws Exception {

        return productService.findProductsBySku(sku);
    }

    @GetMapping(value = "/findTotalProductsBySeller/")
    public int findProductsBySeller(@RequestParam String seller, @RequestParam String category) throws Exception {

        return productService.findProductsBySeller(seller, category.toUpperCase());
    }
}
