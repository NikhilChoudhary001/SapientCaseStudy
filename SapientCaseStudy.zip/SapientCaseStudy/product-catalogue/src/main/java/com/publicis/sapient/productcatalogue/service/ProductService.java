package com.publicis.sapient.productcatalogue.service;

import com.publicis.sapient.productcatalogue.model.Product;
import com.publicis.sapient.productcatalogue.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductService {
    Logger logger = LoggerFactory.getLogger(ProductService.class);

    @Autowired
    private ProductRepository productRepository;

    private static Map<String,Integer> productCategory = new HashMap<>();

    public void addProducts(List<Product> products) {

        logger.info("Adding Product to DB");
        products.stream().forEach(p -> {
            p.setBrand(p.getBrand().toUpperCase());
            p.setCategory(p.getCategory().toUpperCase());

            productRepository.save(p);
        });
    }

    public List<Product> getAllProducts() {

        logger.info("Inside fetch all products method");
        List<Product> products= new ArrayList<>();

        productRepository.findAll().forEach(products::add);
        return products;
    }

    public void deleteProduct(int productId) {
            productRepository.deleteById(productId);
    }

    public List<Product> findProductsByBrand(String brand,String category) {
        logger.info("Group by Brand Name");
        return productRepository.findProductByBrand(brand,category);
    }

    public List<Product> findProductsByPrice(Long minPrice, Long maxPrice, String category) {
        return productRepository.findProductsByPrice(minPrice,maxPrice,category);

    }


    public List<Product> findProductsByColour(String colour, String category) {
        return productRepository.findProductsByColour(colour,category);

    }

    public List<Product> findProductsBySize(String size, String category) {
        return productRepository.findProductsBySize(size,category);

    }

    public List<Product> findProductsBySku(String sku) {
        return productRepository.findProductsBySku(sku);

    }

    public int findProductsBySeller(String seller, String category) {
        return productRepository.findProductsBySeller(seller,category);
    }

}
