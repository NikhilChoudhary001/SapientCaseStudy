package com.publicis.sapient.productcatalogue.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
public class Product implements Serializable {

    @Id
    private int productId;
    private String category;
    private String sku;
    private String seller;
    private String brand;
    private Long price;
    private String colour;
    private String size;

    public Product() {

    }

    public Product(int productId, String category, String sku, String seller, String brand, Long price, String colour, String size) {
        this.productId = productId;
        this.category = category;
        this.sku = sku;
        this.seller = seller;
        this.brand = brand;
        this.price = price;
        this.colour = colour;
        this.size = size;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", category='" + category + '\'' +
                ", sku='" + sku + '\'' +
                ", seller='" + seller + '\'' +
                ", brand='" + brand + '\'' +
                ", price=" + price +
                ", colour='" + colour + '\'' +
                ", size='" + size + '\'' +
                '}';
    }
}