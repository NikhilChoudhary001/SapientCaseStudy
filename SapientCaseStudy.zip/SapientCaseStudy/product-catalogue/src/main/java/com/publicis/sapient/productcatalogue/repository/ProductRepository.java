package com.publicis.sapient.productcatalogue.repository;

import com.publicis.sapient.productcatalogue.model.Product;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends CrudRepository<Product,Integer> {

    @Query("SELECT p FROM Product p WHERE p.brand = ?1 and p.category = ?2")
    List<Product> findProductByBrand(String brand,String category);

    @Query("SELECT p FROM Product p WHERE p.price >= ?1 AND p.price <= ?2 AND p.category = ?3")
    List<Product> findProductsByPrice(Long minPrice, Long maxPrice, String category);

    @Query("SELECT p FROM Product p WHERE p.colour = ?1 and p.category = ?2")
    List<Product> findProductsByColour(String colour, String category);

    @Query("SELECT p FROM Product p WHERE p.size = ?1 and p.category = ?2")
    List<Product> findProductsBySize(String size, String category);

    @Query("SELECT p FROM Product p WHERE p.sku = ?1")
    List<Product> findProductsBySku(String sku);

    @Query("SELECT count(*) FROM Product p WHERE p.seller = ?1 and p.category = ?2")
    int findProductsBySeller(String seller, String category);
}
